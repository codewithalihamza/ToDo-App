import './App.css';
import Todoapp from './component/todoapp';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Gettask from './component/getask';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        
      <BrowserRouter>
     
                <Routes>
                        <Route path='/' element={<Todoapp />} />
                        <Route path='/gettask' element={<Gettask />} />
                    
                </Routes>          
        </BrowserRouter>
      </header>
    </div>
  );
}

export default App;
