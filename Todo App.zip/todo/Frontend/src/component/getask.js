import React from 'react'

const Gettask = () => {
  return (
    <div>
      <h1>Get Task</h1>
    </div>
  )
}

export default Gettask
