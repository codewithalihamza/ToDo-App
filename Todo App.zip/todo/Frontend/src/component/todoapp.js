import React, { useState,useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
function Todoapp() {
    const navigate = useNavigate();
    const[task, setTask] = useState('')


    // semding data to mongo db
    const postingData = async(e) =>{
        e.preventDefault();
        let result = await fetch('http://localhost:5000/task',{
          method: "POST",
          body: JSON.stringify({task}),
          headers:{
            "Content-Type": "application/json",        
          }
        })
        result = await result.json();
        console.log(result)

          navigate("/")
    
      }

      // getting data from mongodb


        const[taskData,setTaskData] = useState([]);
      
      
      
        const getUserData = async() =>{
          let result = await fetch("http://localhost:5000/task")
          result = await result.json();
          setTaskData(result)
        }
        console.log(taskData)
      
      
      
        useEffect(()=>{
          getUserData()
        },[])


        const deleteTask = async(id) => {    
            let res = await fetch(`http://localhost:5000/task/${id}`,{
              method: "delete"
            })
            res = await res.json();
            console.log(res)
            if(res){
              getUserData()
            }
        
          }

  return (
        <>
          <section style={{ backgroundColor: '#eee' }}>
              <div className="h-100">
                  <div className="row d-flex justify-content-center align-items-center h-100">
                      <div className="col ">
                          <div className="card rounded-3">
                              <div className="card-body">
                                  <h4 className="text-center text-dark">To Do App</h4>
                                  <form className="row row-cols-lg-auto g-3 justify-content-center align-items-center mb-4 pb-2">
                                      <div className="col-12">
                                          <div className="form-outline">
                                              <input onChange={(e)=>setTask(e.target.value)} type="text" id="form1" className="form-control" />
                                              <label className="form-label text-dark" htmlFor="form1">Enter a task here</label>
                                          </div>
                                      </div>
                                      <div className="col-12">
                                   
                                          <button onClick={postingData} type="Submit" className="btn btn-primary">Save</button>
                                        
                                      </div>
                                      <div className="col-12">

                                     <Link to='/gettask'  type="submit" className="btn btn-warning">Get tasks  </Link>
                                      </div>
                                  </form>
                                  <table className="table mb-4">
                                      <thead>

                                          <tr>
                                              <th scope="col">No.</th>
                                              <th scope="col">Todo item</th>
                                              <th scope="col">Status</th>
                                              <th scope="col">Actions</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        {
                                         taskData.map((su,ind)=>{
                                            return(

                                          <tr>
                                             <th scope="row">{ind+1}</th>
                                              <td>{su.task}</td>
                                              <td>In progress</td>
                                              <td>
                                                  <button onClick={()=>deleteTask(su._id)} className="btn btn-danger">Delete</button>
                                                  <button type="submit" className="btn btn-success ms-1">Finished</button>
                                              </td>
                                          </tr>
                                             )
                                             })
                                        }
                                      </tbody>
                                  </table>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

        
        </>

    )
}

export default Todoapp